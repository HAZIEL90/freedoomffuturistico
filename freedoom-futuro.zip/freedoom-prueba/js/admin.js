let data = fdLoad();
const key = "fd_admin_prueba";

function showApp() {
  document.querySelector("#login").classList.add("hidden");
  document.querySelector("#app").classList.remove("hidden");
  fill();
  draw();
}
if (sessionStorage.getItem(key) === "1") showApp();

document.querySelector("#login-form").onsubmit = (e) => {
  e.preventDefault();
  if (document.querySelector("#password").value === data.settings.adminPassword) {
    sessionStorage.setItem(key, "1");
    showApp();
  } else document.querySelector("#err").textContent = "Clave incorrecta.";
};
document.querySelector("#logout").onclick = () => { sessionStorage.removeItem(key); location.reload(); };
document.querySelectorAll("[data-view]").forEach((b) => b.onclick = () => {
  document.querySelectorAll("[data-view]").forEach((x) => x.classList.remove("on"));
  b.classList.add("on");
  document.querySelector("#view-products").classList.toggle("hidden", b.dataset.view !== "products");
  document.querySelector("#view-settings").classList.toggle("hidden", b.dataset.view !== "settings");
});

function fill() {
  const f = document.querySelector("#settings-form");
  f.whatsapp.value = data.settings.whatsapp;
  f.tagline.value = data.settings.tagline;
  f.about.value = data.settings.about;
  f.address.value = data.settings.address;
  f.hours.value = data.settings.hours;
  f.instagram.value = data.settings.instagram;
  f.banner.value = data.banner.text;
  f.adminPassword.value = data.settings.adminPassword;
}

function draw() {
  document.querySelector("#rows").innerHTML = data.products.map((p) => `
    <tr>
      <td><img class="thumb" src="${p.image}" alt=""></td>
      <td><strong>${p.name}</strong><div class="muted">${p.category} · ${fdMoney(p.price)} · stock ${p.stock}</div></td>
      <td><button class="btn-ghost" data-del="${p.id}">Quitar</button></td>
    </tr>`).join("") || `<tr><td class="muted">No hay artículos.</td></tr>`;
  document.querySelectorAll("[data-del]").forEach((b) => b.onclick = () => {
    data.products = data.products.filter((p) => p.id !== b.dataset.del);
    fdSave(data);
    draw();
  });
}

document.querySelector("#product-form").onsubmit = (e) => {
  e.preventDefault();
  const f = e.target;
  const file = f.file.files[0];
  if (!file) return;
  if (file.size > 900000) { alert("Usá una foto de menos de 900 KB."); return; }
  const reader = new FileReader();
  reader.onload = () => {
    data.products.unshift({
      id: fdUid("p"),
      name: f.name.value.trim(),
      category: f.category.value,
      price: Number(f.price.value) || 0,
      stock: Number(f.stock.value) || 0,
      sizes: f.sizes.value.trim() || "Único",
      note: f.note.value.trim(),
      image: reader.result,
      active: true
    });
    fdSave(data);
    f.reset();
    draw();
  };
  reader.readAsDataURL(file);
};

document.querySelector("#settings-form").onsubmit = (e) => {
  e.preventDefault();
  const f = e.target;
  data.settings.whatsapp = f.whatsapp.value.trim();
  data.settings.tagline = f.tagline.value.trim();
  data.settings.about = f.about.value.trim();
  data.settings.address = f.address.value.trim();
  data.settings.hours = f.hours.value.trim();
  data.settings.instagram = f.instagram.value.trim();
  data.settings.adminPassword = f.adminPassword.value.trim() || "freedoom";
  data.banner.text = f.banner.value.trim();
  data.banner.active = true;
  fdSave(data);
  alert("Guardado. Recargá la página pública.");
};
