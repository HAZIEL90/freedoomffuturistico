const data = fdLoad();
const state = { filter: "Todo", cart: JSON.parse(localStorage.getItem("fd_cart_prueba") || "[]"), size: "", id: "" };
const cats = ["Todo", "Indumentaria", "Perfumería", "Zapatillas"];

function saveCart() { localStorage.setItem("fd_cart_prueba", JSON.stringify(state.cart)); }
function count() { return state.cart.reduce((n, i) => n + i.qty, 0); }
function total() {
  return state.cart.reduce((n, i) => {
    const p = data.products.find((x) => x.id === i.productId);
    return n + (p ? p.price * i.qty : 0);
  }, 0);
}

document.querySelector("#tagline").textContent = data.settings.tagline;
document.querySelector("#about").textContent = data.settings.about;
document.querySelector("#address").textContent = data.settings.address;
document.querySelector("#hours").textContent = data.settings.hours;
document.querySelector("#contact").textContent = data.settings.instagram ? "Instagram " + data.settings.instagram : "Instagram a cargar en el panel";
document.querySelector("#banner").textContent = data.banner.active ? data.banner.text : "Free Doom";
document.title = "Free Doom · prueba";

document.querySelector("#cats").innerHTML = cats.map((c) => `<button class="cat ${c === state.filter ? "on" : ""}" data-cat="${c}"><span class="muted">0${cats.indexOf(c)} / signal</span><strong>${c}</strong></button>`).join("");
document.querySelectorAll("[data-cat]").forEach((b) => b.addEventListener("click", () => { state.filter = b.dataset.cat; document.querySelectorAll(".cat").forEach((x) => x.classList.toggle("on", x.dataset.cat === state.filter)); render(); }));

function render() {
  const list = data.products.filter((p) => p.active && (state.filter === "Todo" || p.category === state.filter));
  document.querySelector("#count-label").textContent = list.length + " publicados";
  document.querySelector("#grid").innerHTML = list.map((p) => `
    <article class="card">
      <span class="tag">${p.category}</span>
      <div class="shot" style="background-image:url('${p.image}')"></div>
      <div class="pad">
        <div class="muted">Unit ${p.stock > 0 ? p.stock : "consultar"}</div>
        <strong>${p.name}</strong>
        <div class="price">${fdMoney(p.price)}</div>
        <button class="btn" data-open="${p.id}">Abrir ficha</button>
      </div>
    </article>`).join("") || `<p class="muted">Todavía no hay productos en esta categoría. Cargalos en el panel.</p>`;
  document.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () => open(b.dataset.open)));
  document.querySelector("#count").textContent = count();
}

function open(id) {
  const p = data.products.find((x) => x.id === id);
  state.id = id;
  const sizes = String(p.sizes || "Único").split(",").map((s) => s.trim()).filter(Boolean);
  state.size = sizes[0] || "Único";
  document.querySelector("#pshot").style.backgroundImage = `url('${p.image}')`;
  document.querySelector("#pname").textContent = p.name;
  document.querySelector("#pcat").textContent = p.category;
  document.querySelector("#pnote").textContent = p.note || "";
  document.querySelector("#pprice").textContent = fdMoney(p.price);
  document.querySelector("#psizes").innerHTML = sizes.map((s) => `<button type="button" class="size ${s === state.size ? "on" : ""}" data-size="${s}">${s}</button>`).join("");
  document.querySelectorAll("[data-size]").forEach((b) => b.addEventListener("click", () => { state.size = b.dataset.size; open(id); }));
  document.querySelector("#pmodal").classList.add("open");
  document.querySelector("#pback").classList.add("open");
}
function closeP() { document.querySelector("#pmodal").classList.remove("open"); document.querySelector("#pback").classList.remove("open"); }
document.querySelector("#pclose").onclick = closeP;
document.querySelector("#pback").onclick = closeP;
document.querySelector("#padd").onclick = () => {
  const found = state.cart.find((i) => i.productId === state.id && i.size === state.size);
  if (found) found.qty += 1; else state.cart.push({ productId: state.id, size: state.size, qty: 1 });
  saveCart(); closeP(); renderCart(); openC();
};

function renderCart() {
  document.querySelector("#count").textContent = count();
  document.querySelector("#lines").innerHTML = state.cart.map((i, idx) => {
    const p = data.products.find((x) => x.id === i.productId);
    if (!p) return "";
    return `<div class="line"><img src="${p.image}" alt=""><div><strong>${p.name}</strong><div class="muted">${p.category} · ${i.size} · ${i.qty}</div><div class="price">${fdMoney(p.price * i.qty)}</div><button class="btn-ghost" data-rm="${idx}">Quitar</button></div></div>`;
  }).join("") || `<p class="muted">El carrito está vacío.</p>`;
  document.querySelector("#lines").querySelectorAll("[data-rm]").forEach((b) => b.addEventListener("click", () => { state.cart.splice(Number(b.dataset.rm), 1); saveCart(); renderCart(); }));
  document.querySelector("#ship").innerHTML = data.shipping.map((s) => `<option value="${s.name}">${s.name} · ${s.detail}</option>`).join("");
  document.querySelector("#wa-warn").textContent = fdWaNumber(data.settings.whatsapp) ? "" : "Cargá el WhatsApp del local en el panel para que el botón abra el chat.";
}
function openC() { document.querySelector("#cart").classList.add("open"); document.querySelector("#cback").classList.add("open"); renderCart(); }
function closeC() { document.querySelector("#cart").classList.remove("open"); document.querySelector("#cback").classList.remove("open"); }
document.querySelector("#open-cart").onclick = openC;
document.querySelector("#cclose").onclick = closeC;
document.querySelector("#cback").onclick = closeC;

document.querySelector("#order").addEventListener("submit", (event) => {
  event.preventDefault();
  if (!state.cart.length) return;
  const num = fdWaNumber(data.settings.whatsapp);
  if (!num) { alert("Falta el número de WhatsApp. Cargalo en el panel."); return; }
  const fd = new FormData(event.target);
  const lines = state.cart.map((i) => {
    const p = data.products.find((x) => x.id === i.productId);
    return p ? `- ${i.qty} x ${p.name} (${i.size}) ${fdMoney(p.price)}` : "";
  }).filter(Boolean);
  const text = [
    "Hola Free Doom, quiero este pedido:",
    ...lines,
    "Total referencia: " + fdMoney(total()),
    "Nombre: " + fd.get("name"),
    "Localidad: " + fd.get("city"),
    "Entrega: " + fd.get("ship"),
    "Nota: " + (fd.get("note") || "-")
  ].join("\n");
  window.open("https://wa.me/" + num + "?text=" + encodeURIComponent(text), "_blank");
});

render();
renderCart();
