const FD_KEY = "freedoom_prueba_v1";

function fdUid(prefix) {
  return prefix + "_" + Math.random().toString(36).slice(2, 8);
}

function fdMoney(n) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(Number(n) || 0);
}

function fdSeed() {
  return {
    settings: {
      brand: "Free Doom",
      tagline: "Indumentaria, zapatillas y perfumería.",
      about: "Local en Perito Moreno, Santa Cruz. Elegís en la página, armás el carrito y el pedido llega por WhatsApp. Ahí confirmamos stock y te pasamos el link de pago o los datos para transferir.",
      address: "Perito Moreno, Santa Cruz",
      hours: "A confirmar",
      whatsapp: "",
      instagram: "",
      adminPassword: "freedoom"
    },
    banner: { active: true, text: "Pedido por WhatsApp · confirmamos stock y te pasamos el pago" },
    shipping: [
      { id: "pickup", name: "Retiro en el local", detail: "Perito Moreno" },
      { id: "local", name: "Envío en Perito Moreno", detail: "Coordinado por WhatsApp" },
      { id: "pais", name: "Envío al resto del país", detail: "Te cotizamos por mensaje" }
    ],
    products: [
      { id: "ex1", name: "Ejemplo · hoodie", category: "Indumentaria", price: 68900, stock: 4, sizes: "S, M, L, XL", image: "img/hoodie.jpg", note: "Prenda de ejemplo. Borrála y cargá la tuya.", active: true },
      { id: "ex2", name: "Ejemplo · zapatilla", category: "Zapatillas", price: 89900, stock: 2, sizes: "39, 40, 41, 42", image: "img/cap.jpg", note: "Reemplazá esta foto por la de tu par.", active: true },
      { id: "ex3", name: "Ejemplo · perfume", category: "Perfumería", price: 34900, stock: 6, sizes: "50 ml", image: "img/crew.jpg", note: "Cargá la foto real del frasco.", active: true }
    ]
  };
}

function fdLoad() {
  try {
    const raw = localStorage.getItem(FD_KEY);
    if (!raw) {
      const seed = fdSeed();
      localStorage.setItem(FD_KEY, JSON.stringify(seed));
      return seed;
    }
    const data = JSON.parse(raw);
    const seed = fdSeed();
    data.settings = Object.assign({}, seed.settings, data.settings || {});
    data.banner = Object.assign({}, seed.banner, data.banner || {});
    data.shipping = Array.isArray(data.shipping) && data.shipping.length ? data.shipping : seed.shipping;
    data.products = Array.isArray(data.products) ? data.products : [];
    return data;
  } catch (err) {
    const seed = fdSeed();
    localStorage.setItem(FD_KEY, JSON.stringify(seed));
    return seed;
  }
}

function fdSave(data) {
  localStorage.setItem(FD_KEY, JSON.stringify(data));
}

function fdWaNumber(value) {
  return String(value || "").replace(/\D/g, "");
}
